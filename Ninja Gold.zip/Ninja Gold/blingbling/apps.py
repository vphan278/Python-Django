from django.apps import AppConfig


class BlingblingConfig(AppConfig):
    name = 'blingbling'
