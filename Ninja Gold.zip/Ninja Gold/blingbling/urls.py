from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('process_money', views.findgold),
    path('home_page', views.index),
    # two indecies that allow you to restart it or store the money.
]