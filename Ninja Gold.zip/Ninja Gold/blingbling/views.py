from django.shortcuts import render, redirect
import random

def index(request):
    #request.session['gold'] = request.POST['gold']
    #Users gold should start at 0 when the page initially loads
    
    if 'gold' not in request.session:
        request.session['gold'] = 0
        # if it's first time we are on page, start at 0 gold.
    return render(request, 'index.html')


# def new_session
#request.session['gold'] += random_number
def logout(request):
    request.session.flush()
    return redirect('/')

# starts at 0.   .flush vs the clearing the keys = more efficient.


def findgold(request):
    activities = []
    #write if else statement that covers each button
    #one for each Farm, Cave, House, and Casino??
    #request.post['building']
    
# "building" is location but value is "farm/cave/house/casino"
    random_number = 0
    # findgold.building
    if request.POST['building'] == 'farm':
        random_number = random.randint(10,21)
        request.session['gold'] += random_number
        #push the values into activities
        activities.append('Earned {} gold from the farm! ({})')
        #.format time
        #{{ entry.date_added|date:'M d, Y H:i' }}

    if request.POST['building'] == 'cave': 
        random_number = random.randint(5,11)
        request.session['gold'] += random_number
    if request.POST['building'] == 'house': 
        random_number = random.randint(2,6)
        request.session['gold'] += random_number
    if request.POST['building'] == 'casino': 
        random_number = random.randint(-50,51)
        request.session['gold'] += random_number
    # findgold.cave
    # findgold.house
    # findgold.casino
    return redirect('/')

#name="building" = value="farm"
    # context = {
    #     "farm": farm = random.randint(10,21),
    #     "cave": random.randint(5,11),
    #     "cave": random.randint(2,6),
    #     "cave": random.randint(-50,51),        
    # }
#return redirect('/')





# give each button a different id?  depending on the id, do the random.randint()

# Form Submissions: (Random number generator from different ranges)
# import random, at top.
# random.randint(1,100)
# capture returned value by saving to a variable, or writing to session.


# Farm request will add 10-20 to {{your_gold}}
# print "Earned {{gold_amount}} gold from the farm! (time and date stamp)"
# random.randint(10,21)

# Cave request will add 5-10 to {{your_gold}}
# print "Earned {{gold_amount}} gold from the cave! (time and date stamp)"
# random.randint(5,11)


# House request will add 2-5 to {{your_gold}}
# print "Earned {{gold_amount}} gold from the house! (time and date stamp)"
# random.randint(2,6)
# 
# Casino request will make/take 0-50 gold (-50-+50) to {{your_gold}}
# Entered a casino and (lost if negative, won if positive, broke even if 0)
#if negative "Entered a casino and lost {{gold_amount}} gold... Ouch.. (time and date stamp)"
#if positive "Entered a casino and won {{gold_amount}} gold... Awesome! (time and date stamp)"
# random.randint(-50,51)


# name is location but value is "farm/cave/house/casino"
